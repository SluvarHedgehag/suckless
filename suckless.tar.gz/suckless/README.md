config'd suckless utils (and my .kshrc)

================

just clone, go into the folders and doas make clean install

reqs:

void linux: libXft-devel libX11-devel harfbuzz-devel libXext-devel libXrender-devel libXinerama-devel gd-devel

arch linux: gd

and also install jetbrainsmono nerd fonts :)


================

for anyone wondering, dwmism.tar.gz is just an alt version of dwm 

i didn't make anything here myself, go to https://suckless.org/
